package net.sf.jabref.oo;

import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: alver
 * Date: Dec 11, 2007
 * Time: 7:27:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class OOChars {

    
}
